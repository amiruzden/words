from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/longest_words', methods=['POST'])
def longest_words():
    sentence = request.form['sentence']
    
    # Разделяем строку на слова
    words = sentence.split()
    
    # Сортируем слова по длине, затем по алфавиту
    sorted_words = sorted(words, key=lambda x: (-len(x), x))
    
    # Выбираем три самых длинных слова или меньше, если их меньше трех
    longest_words = sorted_words[:3]
    
    return render_template('index.html', longest_words=longest_words)

if __name__ == '__main__':
    app.run(debug=True)
